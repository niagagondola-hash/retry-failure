import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { join } from 'node:path';
import { Logger } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    rawBody: true,
  });

  // Static assets (CSS, JS, images) — /style.css, etc.
  app.useStaticAssets(join(__dirname, '..', 'public'));

  // Views directory (EJS templates) — login.ejs, select-role.ejs, error.ejs
  app.setBaseViewsDir(join(__dirname, '..', 'views'));
  app.setViewEngine('ejs');

  // cookie-parser (akan dipakai untuk auth_sid session)
  const cookieParser = await import('cookie-parser');
  app.use(cookieParser.default());

  app.enableCors({ origin: '*' });

  const port = Number(process.env.AUTH_MOCK_PORT ?? 4001);
  await app.listen(port);

  const logger = new Logger('AuthMock');
  logger.log(`auth-mock listening on http://localhost:${port}`);
  logger.log('⚠️  Development only — do NOT use in production.');
}

bootstrap();
